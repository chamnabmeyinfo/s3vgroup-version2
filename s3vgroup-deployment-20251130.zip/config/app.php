<?php
return [
    'name' => 'S3VGROUP',
    'url' => 'https://s3vgroup.com',  // ⚠️ Use https:// for production
    'timezone' => 'UTC',
    'debug' => false,  // ⚠️ Set to false in production
    'uploads_dir' => __DIR__ . '/../storage/uploads',
    'cache_dir' => __DIR__ . '/../storage/cache',
];

