<?php
return array (
  'enabled' => true,
  'message' => 'Website is under construction',
  'progress' => 85,
  'contact_email' => 'info@s3vgroup.com',
  'contact_phone' => '+1 (234) 567-890',
);
