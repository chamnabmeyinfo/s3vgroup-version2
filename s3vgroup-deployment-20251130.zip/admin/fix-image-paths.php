<?php
/**
 * Fix Image Paths - Remove localhost URLs from database
 * 
 * This script updates all image paths in the database to remove
 * localhost URLs and keep only the filename.
 * 
 * Example:
 * Before: http://localhost:8080/storage/uploads/img_692b6e850a1386.91083690.png
 * After: img_692b6e850a1386.91083690.png
 */
require_once __DIR__ . '/../bootstrap/app.php';
require_once __DIR__ . '/includes/auth.php';

$message = '';
$error = '';
$results = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fix_paths'])) {
    try {
        $db = db();
        $pdo = $db->getPdo();
        $pdo->beginTransaction();
        
        $updated = 0;
        $checked = 0;
        
        // 1. Fix products table - image field
        try {
            $products = $db->fetchAll("SELECT id, image FROM products WHERE image IS NOT NULL AND image != ''");
            foreach ($products as $product) {
                $checked++;
                $oldImage = $product['image'];
                $newImage = cleanImagePath($oldImage);
                
                if ($oldImage !== $newImage) {
                    $db->update('products', ['image' => $newImage], 'id = :id', ['id' => $product['id']]);
                    $updated++;
                    $results[] = "Product #{$product['id']}: {$oldImage} → {$newImage}";
                }
            }
        } catch (Exception $e) {
            $results[] = "Products table: " . $e->getMessage();
        }
        
        // 2. Fix products table - gallery field (JSON)
        try {
            $products = $db->fetchAll("SELECT id, gallery FROM products WHERE gallery IS NOT NULL AND gallery != ''");
            foreach ($products as $product) {
                $checked++;
                $gallery = json_decode($product['gallery'], true);
                if (is_array($gallery)) {
                    $updatedGallery = false;
                    $newGallery = [];
                    foreach ($gallery as $img) {
                        $cleaned = cleanImagePath($img);
                        $newGallery[] = $cleaned;
                        if ($img !== $cleaned) {
                            $updatedGallery = true;
                        }
                    }
                    if ($updatedGallery) {
                        $db->update('products', ['gallery' => json_encode($newGallery)], 'id = :id', ['id' => $product['id']]);
                        $updated++;
                        $results[] = "Product #{$product['id']} gallery: Updated " . count($newGallery) . " images";
                    }
                }
            }
        } catch (Exception $e) {
            $results[] = "Products gallery: " . $e->getMessage();
        }
        
        // 3. Fix categories table - image field
        try {
            $categories = $db->fetchAll("SELECT id, image FROM categories WHERE image IS NOT NULL AND image != ''");
            foreach ($categories as $category) {
                $checked++;
                $oldImage = $category['image'];
                $newImage = cleanImagePath($oldImage);
                
                if ($oldImage !== $newImage) {
                    $db->update('categories', ['image' => $newImage], 'id = :id', ['id' => $category['id']]);
                    $updated++;
                    $results[] = "Category #{$category['id']}: {$oldImage} → {$newImage}";
                }
            }
        } catch (Exception $e) {
            $results[] = "Categories table: " . $e->getMessage();
        }
        
        // 4. Fix product_variants table - image field
        try {
            $variants = $db->fetchAll("SELECT id, image FROM product_variants WHERE image IS NOT NULL AND image != ''");
            foreach ($variants as $variant) {
                $checked++;
                $oldImage = $variant['image'];
                $newImage = cleanImagePath($oldImage);
                
                if ($oldImage !== $newImage) {
                    $db->update('product_variants', ['image' => $newImage], 'id = :id', ['id' => $variant['id']]);
                    $updated++;
                    $results[] = "Variant #{$variant['id']}: {$oldImage} → {$newImage}";
                }
            }
        } catch (Exception $e) {
            $results[] = "Product variants: " . $e->getMessage();
        }
        
        // 5. Fix any other tables that might have image paths
        // Check settings table for logo or other images
        try {
            $settings = $db->fetchAll("SELECT id, `key`, value FROM settings WHERE value LIKE '%localhost%' OR value LIKE '%storage/uploads%'");
            foreach ($settings as $setting) {
                $checked++;
                $oldValue = $setting['value'];
                $newValue = cleanImagePath($oldValue);
                
                if ($oldValue !== $newValue) {
                    $db->update('settings', ['value' => $newValue], 'id = :id', ['id' => $setting['id']]);
                    $updated++;
                    $results[] = "Setting '{$setting['key']}': Updated";
                }
            }
        } catch (Exception $e) {
            // Settings table might not exist or have image fields
        }
        
        $pdo->commit();
        $message = "Successfully updated {$updated} image path(s) out of {$checked} checked.";
        
    } catch (Exception $e) {
        if (isset($pdo)) {
            $pdo->rollBack();
        }
        $error = "Error: " . $e->getMessage();
    }
}

/**
 * Clean image path - remove localhost URL and keep only filename
 */
function cleanImagePath($path) {
    if (empty($path)) {
        return $path;
    }
    
    // Remove http://localhost:8080 or https://localhost:8080
    $path = preg_replace('#https?://localhost:?\d*/?#i', '', $path);
    
    // Remove http://127.0.0.1:8080
    $path = preg_replace('#https?://127\.0\.0\.1:?\d*/?#i', '', $path);
    
    // Remove storage/uploads/ prefix if present
    $path = preg_replace('#^storage/uploads/#i', '', $path);
    
    // Remove any leading slashes
    $path = ltrim($path, '/');
    
    // Remove any domain URLs (keep only relative paths)
    if (preg_match('#^https?://#i', $path)) {
        // Extract filename from URL
        $path = basename(parse_url($path, PHP_URL_PATH));
    }
    
    return $path;
}

$pageTitle = 'Fix Image Paths';
include __DIR__ . '/includes/header.php';

// Preview what will be changed
$preview = [];
try {
    $db = db();
    
    // Check products
    $products = $db->fetchAll("SELECT id, name, image FROM products WHERE image LIKE '%localhost%' OR image LIKE '%storage/uploads%' LIMIT 10");
    foreach ($products as $product) {
        $preview[] = [
            'table' => 'products',
            'id' => $product['id'],
            'name' => $product['name'],
            'old' => $product['image'],
            'new' => cleanImagePath($product['image'])
        ];
    }
    
    // Check categories
    $categories = $db->fetchAll("SELECT id, name, image FROM categories WHERE image LIKE '%localhost%' OR image LIKE '%storage/uploads%' LIMIT 10");
    foreach ($categories as $category) {
        $preview[] = [
            'table' => 'categories',
            'id' => $category['id'],
            'name' => $category['name'],
            'old' => $category['image'],
            'new' => cleanImagePath($category['image'])
        ];
    }
} catch (Exception $e) {
    // Ignore preview errors
}
?>

<div class="p-6">
    <div class="mb-6">
        <h1 class="text-3xl font-bold">Fix Image Paths</h1>
        <p class="text-gray-600 mt-2">Remove localhost URLs from database and keep only filenames.</p>
    </div>
    
    <?php if ($message): ?>
    <div class="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded">
        <strong>Success!</strong> <?= escape($message) ?>
        <?php if (!empty($results) && count($results) <= 20): ?>
            <div class="mt-4 text-sm">
                <strong>Details:</strong>
                <ul class="list-disc list-inside mt-2">
                    <?php foreach ($results as $result): ?>
                        <li><?= escape($result) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div class="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
        <?= escape($error) ?>
    </div>
    <?php endif; ?>
    
    <!-- Preview -->
    <?php if (!empty($preview)): ?>
    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 class="text-xl font-bold mb-4">Preview Changes</h2>
        <p class="text-sm text-gray-600 mb-4">These are sample records that will be updated:</p>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b">
                        <th class="text-left p-2">Table</th>
                        <th class="text-left p-2">ID</th>
                        <th class="text-left p-2">Name</th>
                        <th class="text-left p-2">Old Path</th>
                        <th class="text-left p-2">New Path</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($preview as $item): ?>
                    <tr class="border-b">
                        <td class="p-2"><?= escape($item['table']) ?></td>
                        <td class="p-2">#<?= escape($item['id']) ?></td>
                        <td class="p-2"><?= escape($item['name']) ?></td>
                        <td class="p-2 text-red-600 font-mono text-xs"><?= escape($item['old']) ?></td>
                        <td class="p-2 text-green-600 font-mono text-xs"><?= escape($item['new']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Info Box -->
    <div class="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
        <h3 class="font-bold text-blue-900 mb-2">
            <i class="fas fa-info-circle mr-2"></i>
            What This Does
        </h3>
        <ul class="list-disc list-inside text-blue-800 space-y-1 text-sm">
            <li>Removes <code>http://localhost:8080</code> from image paths</li>
            <li>Removes <code>storage/uploads/</code> prefix (keeps only filename)</li>
            <li>Updates all tables: products, categories, variants, settings</li>
            <li>Fixes both single image fields and JSON gallery fields</li>
            <li>Creates a backup before making changes (transaction-based)</li>
        </ul>
        <div class="mt-4 p-3 bg-yellow-100 border border-yellow-300 rounded">
            <strong class="text-yellow-900">⚠️ Important:</strong>
            <p class="text-yellow-800 text-sm mt-1">
                Make sure your image files are already uploaded to <code>storage/uploads/</code> on the server.
                This script only fixes the database paths, not the actual files.
            </p>
        </div>
    </div>
    
    <!-- Action -->
    <form method="POST">
        <button type="submit" name="fix_paths" class="btn-primary" onclick="return confirm('This will update all image paths in the database. Continue?');">
            <i class="fas fa-wrench mr-2"></i>
            Fix Image Paths
        </button>
    </form>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

