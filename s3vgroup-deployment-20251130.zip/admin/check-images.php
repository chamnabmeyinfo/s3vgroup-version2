<?php
/**
 * Image Diagnostic Tool
 * Checks why images aren't loading
 */
require_once __DIR__ . '/../bootstrap/app.php';
require_once __DIR__ . '/includes/auth.php';

$pageTitle = 'Image Diagnostic Tool';
include __DIR__ . '/includes/header.php';

$issues = [];
$warnings = [];
$success = [];

// Check 1: Config URL
$configUrl = config('app.url', '');
if (strpos($configUrl, 'localhost') !== false) {
    $issues[] = "Config URL still has localhost: {$configUrl}";
} else {
    $success[] = "Config URL is correct: {$configUrl}";
}

// Check 2: Storage directory exists
$uploadsDir = __DIR__ . '/../storage/uploads';
if (!is_dir($uploadsDir)) {
    $issues[] = "storage/uploads directory doesn't exist!";
} else {
    $success[] = "storage/uploads directory exists";
    
    // Check permissions
    $perms = substr(sprintf('%o', fileperms($uploadsDir)), -4);
    if ($perms !== '0755' && $perms !== '0777') {
        $warnings[] = "storage/uploads permissions are {$perms} (should be 755 or 777)";
    } else {
        $success[] = "storage/uploads permissions are correct ({$perms})";
    }
}

// Check 3: Sample products with images
try {
    $db = db();
    $products = $db->fetchAll("SELECT id, name, image FROM products WHERE image IS NOT NULL AND image != '' LIMIT 10");
    
    if (empty($products)) {
        $warnings[] = "No products with images found in database";
    } else {
        $success[] = "Found " . count($products) . " products with images";
        
        // Check image paths
        $hasLocalhost = 0;
        $hasFullPath = 0;
        $correctFormat = 0;
        
        foreach ($products as $product) {
            $image = $product['image'];
            
            if (strpos($image, 'localhost') !== false) {
                $hasLocalhost++;
            } elseif (strpos($image, 'storage/uploads') !== false || strpos($image, '/') !== false) {
                $hasFullPath++;
            } else {
                $correctFormat++;
            }
        }
        
        if ($hasLocalhost > 0) {
            $issues[] = "{$hasLocalhost} products still have localhost URLs in database";
        }
        if ($hasFullPath > 0) {
            $warnings[] = "{$hasFullPath} products have full paths (should be just filename)";
        }
        if ($correctFormat > 0) {
            $success[] = "{$correctFormat} products have correct image format (just filename)";
        }
        
        // Check if files exist
        $missingFiles = 0;
        $existingFiles = 0;
        
        foreach ($products as $product) {
            $imageFile = $uploadsDir . '/' . basename($product['image']);
            if (file_exists($imageFile)) {
                $existingFiles++;
            } else {
                $missingFiles++;
            }
        }
        
        if ($missingFiles > 0) {
            $issues[] = "{$missingFiles} image files are missing from storage/uploads/";
        }
        if ($existingFiles > 0) {
            $success[] = "{$existingFiles} image files exist on server";
        }
    }
} catch (Exception $e) {
    $issues[] = "Error checking products: " . $e->getMessage();
}

// Check 4: Test image URL generation
$testImage = 'test-image.png';
$testUrl = asset('storage/uploads/' . $testImage);
$expectedUrl = rtrim(config('app.url', ''), '/') . '/storage/uploads/' . $testImage;

if ($testUrl === $expectedUrl) {
    $success[] = "Image URL generation is working correctly";
} else {
    $issues[] = "Image URL generation issue. Expected: {$expectedUrl}, Got: {$testUrl}";
}

?>

<div class="p-6">
    <div class="mb-6">
        <h1 class="text-3xl font-bold">Image Diagnostic Tool</h1>
        <p class="text-gray-600 mt-2">This tool checks why images might not be loading.</p>
    </div>
    
    <!-- Issues -->
    <?php if (!empty($issues)): ?>
    <div class="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
        <h2 class="font-bold text-lg mb-2">
            <i class="fas fa-exclamation-triangle mr-2"></i>
            Issues Found (<?= count($issues) ?>)
        </h2>
        <ul class="list-disc list-inside space-y-1">
            <?php foreach ($issues as $issue): ?>
                <li><?= escape($issue) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    
    <!-- Warnings -->
    <?php if (!empty($warnings)): ?>
    <div class="mb-6 p-4 bg-yellow-100 border border-yellow-400 text-yellow-700 rounded">
        <h2 class="font-bold text-lg mb-2">
            <i class="fas fa-exclamation-circle mr-2"></i>
            Warnings (<?= count($warnings) ?>)
        </h2>
        <ul class="list-disc list-inside space-y-1">
            <?php foreach ($warnings as $warning): ?>
                <li><?= escape($warning) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    
    <!-- Success -->
    <?php if (!empty($success)): ?>
    <div class="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded">
        <h2 class="font-bold text-lg mb-2">
            <i class="fas fa-check-circle mr-2"></i>
            Working Correctly (<?= count($success) ?>)
        </h2>
        <ul class="list-disc list-inside space-y-1">
            <?php foreach ($success as $item): ?>
                <li><?= escape($item) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    
    <!-- Quick Actions -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <h2 class="text-xl font-bold mb-4">Quick Actions</h2>
        <div class="space-y-2">
            <a href="<?= url('admin/fix-image-paths.php') ?>" class="btn-primary inline-block">
                <i class="fas fa-wrench mr-2"></i>
                Fix Image Paths in Database
            </a>
            <a href="<?= url('admin/products.php') ?>" class="btn-secondary inline-block ml-2">
                <i class="fas fa-box mr-2"></i>
                Go to Products
            </a>
        </div>
    </div>
    
    <!-- Sample Products -->
    <?php if (!empty($products)): ?>
    <div class="mt-6 bg-white rounded-lg shadow-md p-6">
        <h2 class="text-xl font-bold mb-4">Sample Products Check</h2>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b">
                        <th class="text-left p-2">ID</th>
                        <th class="text-left p-2">Name</th>
                        <th class="text-left p-2">Image Path</th>
                        <th class="text-left p-2">File Exists</th>
                        <th class="text-left p-2">Generated URL</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (array_slice($products, 0, 5) as $product): ?>
                    <?php
                        $imageFile = $uploadsDir . '/' . basename($product['image']);
                        $fileExists = file_exists($imageFile);
                        $generatedUrl = asset('storage/uploads/' . basename($product['image']));
                    ?>
                    <tr class="border-b">
                        <td class="p-2">#<?= $product['id'] ?></td>
                        <td class="p-2"><?= escape($product['name']) ?></td>
                        <td class="p-2 font-mono text-xs"><?= escape($product['image']) ?></td>
                        <td class="p-2">
                            <?php if ($fileExists): ?>
                                <span class="text-green-600">✓ Yes</span>
                            <?php else: ?>
                                <span class="text-red-600">✗ No</span>
                            <?php endif; ?>
                        </td>
                        <td class="p-2">
                            <a href="<?= escape($generatedUrl) ?>" target="_blank" class="text-blue-600 hover:underline text-xs">
                                <?= escape($generatedUrl) ?>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

