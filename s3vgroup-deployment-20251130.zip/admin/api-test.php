<?php
/**
 * API Testing Interface
 */
require_once __DIR__ . '/../bootstrap/app.php';
require_once __DIR__ . '/includes/auth.php';

$pageTitle = 'API Testing';
include __DIR__ . '/includes/header.php';
?>

<div class="p-6">
    <h1 class="text-2xl font-bold mb-6">API Testing Interface</h1>
    
    <div class="grid md:grid-cols-2 gap-6">
        <!-- API Endpoints -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold mb-4">Available API Endpoints</h2>
            <div class="space-y-3">
                <div class="border rounded-lg p-4">
                    <div class="flex items-center justify-between mb-2">
                        <span class="font-semibold">GET /api/v1/products</span>
                        <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">GET</span>
                    </div>
                    <p class="text-sm text-gray-600">List all products</p>
                    <code class="text-xs block mt-2 bg-gray-100 p-2 rounded"><?= url('api/v1/products.php') ?></code>
                </div>
                
                <div class="border rounded-lg p-4">
                    <div class="flex items-center justify-between mb-2">
                        <span class="font-semibold">GET /api/v1/products/{id}</span>
                        <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">GET</span>
                    </div>
                    <p class="text-sm text-gray-600">Get single product</p>
                </div>
                
                <div class="border rounded-lg p-4">
                    <div class="flex items-center justify-between mb-2">
                        <span class="font-semibold">POST /api/v1/products</span>
                        <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">POST</span>
                    </div>
                    <p class="text-sm text-gray-600">Create new product (Auth required)</p>
                </div>
                
                <div class="border rounded-lg p-4">
                    <div class="flex items-center justify-between mb-2">
                        <span class="font-semibold">PUT /api/v1/products/{id}</span>
                        <span class="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">PUT</span>
                    </div>
                    <p class="text-sm text-gray-600">Update product (Auth required)</p>
                </div>
                
                <div class="border rounded-lg p-4">
                    <div class="flex items-center justify-between mb-2">
                        <span class="font-semibold">DELETE /api/v1/products/{id}</span>
                        <span class="text-xs bg-red-100 text-red-800 px-2 py-1 rounded">DELETE</span>
                    </div>
                    <p class="text-sm text-gray-600">Delete product (Auth required)</p>
                </div>
            </div>
        </div>
        
        <!-- API Tester -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold mb-4">Test API Request</h2>
            
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium mb-2">Method</label>
                    <select id="api-method" class="w-full px-4 py-2 border rounded-lg">
                        <option value="GET">GET</option>
                        <option value="POST">POST</option>
                        <option value="PUT">PUT</option>
                        <option value="DELETE">DELETE</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-sm font-medium mb-2">Endpoint</label>
                    <input type="text" id="api-endpoint" 
                           value="<?= url('api/v1/products.php') ?>"
                           class="w-full px-4 py-2 border rounded-lg">
                </div>
                
                <div>
                    <label class="block text-sm font-medium mb-2">Request Body (JSON)</label>
                    <textarea id="api-body" rows="6" 
                              class="w-full px-4 py-2 border rounded-lg font-mono text-sm"
                              placeholder='{"name": "Product Name", "price": 100}'></textarea>
                </div>
                
                <button onclick="testApi()" class="btn-primary w-full">
                    <i class="fas fa-paper-plane mr-2"></i> Send Request
                </button>
            </div>
            
            <div id="api-response" class="mt-6 hidden">
                <h3 class="font-bold mb-2">Response</h3>
                <pre class="bg-gray-100 p-4 rounded text-sm overflow-x-auto max-h-96 overflow-y-auto"></pre>
            </div>
        </div>
    </div>
</div>

<script>
async function testApi() {
    const method = document.getElementById('api-method').value;
    const endpoint = document.getElementById('api-endpoint').value;
    const body = document.getElementById('api-body').value;
    const responseDiv = document.getElementById('api-response');
    const pre = responseDiv.querySelector('pre');
    
    responseDiv.classList.remove('hidden');
    pre.textContent = 'Loading...';
    
    try {
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            }
        };
        
        if (body && (method === 'POST' || method === 'PUT')) {
            options.body = body;
        }
        
        const response = await fetch(endpoint, options);
        const data = await response.json();
        
        pre.textContent = JSON.stringify(data, null, 2);
        pre.className = 'bg-gray-100 p-4 rounded text-sm overflow-x-auto max-h-96 overflow-y-auto ' + 
                       (response.ok ? 'border-2 border-green-500' : 'border-2 border-red-500');
    } catch (error) {
        pre.textContent = 'Error: ' + error.message;
        pre.className = 'bg-red-100 p-4 rounded text-sm overflow-x-auto border-2 border-red-500';
    }
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>

